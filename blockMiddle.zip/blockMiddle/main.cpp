#include <iostream>
#include "middle.h"

using namespace std;

int main()
{
    cout <<itc_len_num(12098094200)<< endl;
    cout << itc_sum_num(12098094200) << endl;
    cout << itc_multi_num(12345) << endl;
    cout << itc_max_num(12098094200) << endl;
    cout << itc_min_num(12320) << endl;
    return 0;
}
