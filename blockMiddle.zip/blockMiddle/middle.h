#ifndef MIDDLE_H_INCLUDED
#define MIDDLE_H_INCLUDED

int itc_len_num(long long number);
int itc_sum_num(long long number);
long long itc_multi_num(long long number);
int itc_max_num(long long number);
int itc_revnbr(int num);
int itc_min_num(long long number);

#endif // MIDDLE_H_INCLUDED
